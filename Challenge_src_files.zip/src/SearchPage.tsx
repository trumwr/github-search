import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import axios, { AxiosError, isCancel } from 'axios';
import { TEXT } from './constants';
import ReactDataGrid, { TypeColumn } from '@inovua/reactdatagrid-community';
import '@inovua/reactdatagrid-community/index.css';

type Repo = {
    id: number;
    name: string;
    html_url: string;
    owner: { login: string; html_url: string };
    description: string;
    stargazers_count: number;
    forks_count: number;
    open_issues_count: number;
    license?: { name: string };
};

interface GitHubApiResponse {
    items: Repo[];
    total_count: number;
    incomplete_results: boolean;
}

const LANGUAGE_MAP: Record<string, string> = {
    javascript: 'javascript',
    typescript: 'typescript',
    'c#': 'csharp'
};

const SearchPage: React.FC = () => {
    const [language, setLanguage] = useState('javascript');
    const [repos, setRepos] = useState<Repo[]>([]);
    const [loading, setLoading] = useState(false);
    const [page, setPage] = useState(1);
    const [error, setError] = useState<string | null>(null);
    const navigate = useNavigate();

    const fetchRepos = useCallback(
        async (lang: string, pageNum: number) => {
            setError(null);
            const controller = new AbortController();

            try {
                setLoading(true);
                const apiLang = LANGUAGE_MAP[lang.toLowerCase()];

                // Temporary type assertion to work around Axios type mismatch
                // Functional but would improve types in production code
                const response = await axios.get<GitHubApiResponse>(
                    `https://api.github.com/search/repositories?q=language:${apiLang}&sort=stars&order=desc&per_page=10&page=${pageNum}`,
                    {
                        signal: controller.signal
                    } as any
                );

                setRepos(prev =>
                    pageNum === 1 ? response.data.items : [...prev, ...response.data.items]
                );
            } catch (error) {
                const axiosError = error as AxiosError;
                if (!isCancel(axiosError)) {
                    console.error(axiosError);
                    setError('Failed to fetch repositories');
                }
            } finally {
                setLoading(false);
            }

            return () => controller.abort();
        },
        []
    );

    useEffect(() => {
        const controller = new AbortController();
        fetchRepos(language, page);
        return () => controller.abort();
    }, [fetchRepos, language, page]);

    const columns: TypeColumn[] = [
        {
            name: 'name',
            header: 'Repository',
            render: ({ data }: { data: Repo }) => (
                <a href={data.html_url} target="_blank" rel="noopener noreferrer">
                    {data.name}
                </a>
            )
        },
        {
            name: 'description',
            header: 'Description',
            flex: 2,
            render: ({ data }: { data: Repo }) => data.description || 'No description'
        },
        {
            name: 'details',
            header: 'Details',
            render: ({ data }: { data: Repo }) => (
                <button
                    onClick={() => navigate(`/details/${data.id}`, { state: data })}
                    className="details-button"
                >
                    View Details
                </button>
            )
        }
    ];

    return (
        <div className="search-page">
            <h1>{TEXT.SEARCH_TITLE}</h1>

            <div className="language-selector">
                <label>{TEXT.SELECT_LANGUAGE}</label>
                <select
                    value={language}
                    onChange={(e) => {
                        setLanguage(e.target.value);
                        setPage(1);
                    }}
                >
                    <option value="javascript">JavaScript</option>
                    <option value="typescript">TypeScript</option>
                    <option value="c#">C#</option>
                </select>
            </div>

            {repos.length === 0 && !loading && (
                <div className="no-results">
                    {`No ${LANGUAGE_MAP[language]} repositories found`}
                </div>
            )}
            {error && <p style={{ color: "red" }}>{error}</p>}
            <ReactDataGrid
                idProperty="id"
                columns={columns}
                dataSource={repos}
                style={{ minHeight: 500 }}
                loading={loading}
                pagination
                onPageChange={({ page }: { page: number }) => setPage(page)}
            />
        </div>
    );
};

export default SearchPage;