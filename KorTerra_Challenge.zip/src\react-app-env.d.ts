/// <reference types="react-scripts" />

declare module 'axios' {  
    export interface AxiosError<T = unknown> extends Error {
        config: AxiosRequestConfig;
        code?: string;
        request?: unknown;
        response?: AxiosResponse<T>;
        isAxiosError: boolean;
    }

    export interface AxiosRequestConfig {
        signal?: AbortSignal;
    }

    export function isCancel(value: unknown): boolean;
}